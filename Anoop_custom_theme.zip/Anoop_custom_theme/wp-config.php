<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'Anoop_custom_theme' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '<M^^d*HS-F7V?5qtNR XhPmN2S,]A%jY~2g*cc2!w6ka kr5xC-?Q].FW.7ceb1e' );
define( 'SECURE_AUTH_KEY',  ':{~^gWE}6Qtzbv-x@$kLyBCe PZ3ep|^cTq]H!FWPV$$|!3=z,RE2/]iMsuJH[;R' );
define( 'LOGGED_IN_KEY',    'Gmv5g^G8^SBPIi[cZd-:2x5>&&=h(XCouT%<!i.r9+h_Qb?MQ(<2|+!~I2eJ9 wr' );
define( 'NONCE_KEY',        '3QI_g[((m(c$c/m.$$<sZWAs$$dfezlFF5Zv@E2N2r[5H4**K_v[aK5U!3IPT}D=' );
define( 'AUTH_SALT',        '8whH$aQomoZqU$n;<T,`Ze?Dz$OLN53]G-QNsw=#W4,Ec|hVH$?suO;_FXO_9:b8' );
define( 'SECURE_AUTH_SALT', 'MZ$1K`eaD31;T:(se9.uZK]UH/[=8=WZ&Eza>N9,a+bff?i)GHh39o uI;1 6~N^' );
define( 'LOGGED_IN_SALT',   '[%ecorTE>YL6#$F/qF2HcHCGf)23?qQSLoq{&0tqUg^jG{QBLBOuapl{Cyz`{j?)' );
define( 'NONCE_SALT',       '-sB-b%U%U)/*B`?T[}2-p1eBAQAr_<V$P9W*`uPPHNk}_G3IS=T.VQ,Zp_QniWZl' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
