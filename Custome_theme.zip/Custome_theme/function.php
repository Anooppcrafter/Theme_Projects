<?php

function Anoop_custom_theme_script(){

// stylesheets
wp_enqueue_style('main_style_file',get_stylesheet_url());
	wp_enqueue_style('Css_file',get_template_directory_url().'/css/bootstrap.min.css');
	wp_enqueue_style('Css_file',get_template_directory_url().'/fonts/icomoon/style.css');
	wp_enqueue_style('Css_file',get_template_directory_url().'/css/jquery-ui.css');
	wp_enqueue_style('Css_file',get_template_directory_url().'/css/owl.carousel.min.css');
	wp_enqueue_style('Css_file',get_template_directory_url().'/css/owl.theme.default.min.css');
	wp_enqueue_style('Css_file',get_template_directory_url().'/css/owl.theme.default.min.css');
	wp_enqueue_style('Css_fileCss_fileCss_fileCss_file',get_template_directory_url().'/css/jquery.fancybox.min.css');
	wp_enqueue_style('Css_fileCss_fileCss_file',get_template_directory_url().'/css/bootstrap-datepicker.css');
	wp_enqueue_style('Css_fileCss_file',get_template_directory_url().'/fonts/flaticon/font/flaticon.css');
	wp_enqueue_style('Css_file',get_template_directory_url().'/css/aos.css');
	wp_enqueue_style('Css_file',get_template_directory_url().'/css/style.css');

//javascripts
	wp_enqueue_style('js_main_file',get_template_directory_url().'/js/jquery-3.3.1.min.js',array(),'1.1',true);
	wp_enqueue_style('js_main_file',get_template_directory_url().'/js/jquery-ui.js',array(),'1.1',true);
	wp_enqueue_style('js_main_file',get_template_directory_url().'/js/popper.min.js',array(),'1.1',true);
	wp_enqueue_style('js_main_file',get_template_directory_url().'/js/bootstrap.min.js',array(),'1.1',true);
	wp_enqueue_style('js_main_file',get_template_directory_url().'/js/owl.carousel.min.js',array(),'1.1',true);
	wp_enqueue_style('js_main_file',get_template_directory_url().'/js/jquery.countdown.min.js',array(),'1.1',true);
	wp_enqueue_style('js_main_file',get_template_directory_url().'/js/jquery.easing.1.3.js',array(),'1.1',true);
	wp_enqueue_style('js_main_file',get_template_directory_url().'/js/aos.js',array(),'1.1',true);
	wp_enqueue_style('js_main_file',get_template_directory_url().'/js/jquery.fancybox.min.js',array(),'1.1',true);

wp_enqueue_style('js_main_file',get_template_directory_url().'/js/jquery.sticky.js',array(),'1.1',true);

wp_enqueue_style('js_main_file',get_template_directory_url().'/js/isotope.pkgd.min.js',array(),'1.1',true);
wp_enqueue_style('js_main_file',get_template_directory_url().'/js/main.js',array(),'1.1',true);


	//attach with action hook

	add_action("wp_enqueue_scripts","Anoop_custom_theme_script");

	function register_Anoop_custom_theme(){

		//menu register code

		register_nav_menus{
			array{
				'primary-menu' =>__('Primary Menu'),
				'footer-menu' =>__('Footer Menu')
			}
		};
	}
		add_action('init','register_Anoop_custom_theme');
?>

